import SwiftUI

@main
struct AddonAIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
