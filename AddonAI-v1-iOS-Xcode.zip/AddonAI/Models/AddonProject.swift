import Foundation

struct AddonProject: Identifiable, Codable {
    let id: UUID
    var name: String
    var prompt: String
    var createdAt: Date
    var behaviorJSON: String
    var resourceJSON: String

    init(
        id: UUID = UUID(),
        name: String,
        prompt: String,
        createdAt: Date = .now,
        behaviorJSON: String = "{}",
        resourceJSON: String = "{}"
    ) {
        self.id = id
        self.name = name
        self.prompt = prompt
        self.createdAt = createdAt
        self.behaviorJSON = behaviorJSON
        self.resourceJSON = resourceJSON
    }
}
