import SwiftUI

struct ContentView: View {
    @State private var prompt = ""
    @AppStorage("addonai.projects") private var storedProjects = Data()
    @State private var projects: [AddonProject] = []
    @State private var isGenerating = false
    @State private var errorMessage: String?
    @State private var exportedURL: URL?
    @State private var showingShare = false

    private let generator = AddonGenerator()

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("✨ Create an addon")
                            .font(.title2.bold())

                        Text("Describe what you want Minecraft Bedrock to contain.")
                            .foregroundStyle(.secondary)

                        TextEditor(text: $prompt)
                            .frame(minHeight: 130)
                            .padding(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(.quaternary)
                            )

                        Button {
                            generate()
                        } label: {
                            HStack {
                                if isGenerating {
                                    ProgressView().tint(.white)
                                }
                                Text(isGenerating ? "Generating…" : "Generate Addon")
                                    .fontWeight(.semibold)
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(isGenerating || prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                    .padding(.vertical, 8)
                }

                Section("My Addons") {
                    if projects.isEmpty {
                        ContentUnavailableView(
                            "No addons yet",
                            systemImage: "shippingbox",
                            description: Text("Your generated addons will appear here.")
                        )
                    } else {
                        ForEach(projects) { project in
                            HStack {
                                Image(systemName: "cube.fill")
                                VStack(alignment: .leading) {
                                    Text(project.name)
                                        .font(.headline)
                                    Text(project.prompt)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(2)
                                }
                                Spacer()
                                Button("Export") {
                                    export(project)
                                }
                                .buttonStyle(.bordered)
                            }
                            .padding(.vertical, 4)
                        }
                        .onDelete { projects.remove(atOffsets: $0) }
                    }
                }
            }
            .navigationTitle("AddonAI")
            .onAppear { loadProjects() }
            .onChange(of: projects) { _, _ in saveProjects() }
            .sheet(isPresented: $showingShare) {
                if let exportedURL {
                    ShareSheet(items: [exportedURL])
                }
            }
            .alert(
                "AddonAI",
                isPresented: Binding(
                    get: { errorMessage != nil },
                    set: { if !$0 { errorMessage = nil } }
                )
            ) {
                Button("OK") { errorMessage = nil }
            } message: {
                Text(errorMessage ?? "")
            }
        }
    }

    private func generate() {
        isGenerating = true
        Task {
            do {
                let result = try await generator.generate(prompt: prompt)
                let project = AddonProject(
                    name: result.name,
                    prompt: prompt,
                    behaviorJSON: result.behaviorManifest,
                    resourceJSON: result.resourceManifest
                )
                await MainActor.run {
                    projects.insert(project, at: 0)
                    prompt = ""
                    isGenerating = false
                }
            } catch {
                await MainActor.run {
                    isGenerating = false
                    errorMessage = "Generation failed. Please try again."
                }
            }
        }
    }

    private func export(_ project: AddonProject) {
        do {
            exportedURL = try AddonExporter.export(project: project)
            showingShare = true
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}

private extension ContentView {
    func loadProjects() {
        if let decoded = try? JSONDecoder().decode([AddonProject].self, from: storedProjects) {
            projects = decoded
        }
    }

    func saveProjects() {
        if let encoded = try? JSONEncoder().encode(projects) {
            storedProjects = encoded
        }
    }
}
