
import Foundation

struct AddonExporter {
    static func export(project: AddonProject) throws -> URL {
        let entity = """
        {
          "format_version": "1.20.0",
          "minecraft:entity": {
            "description": {
              "identifier": "addonai:generated_entity",
              "is_spawnable": true,
              "is_summonable": true
            }
          }
        }
        """

        let files: [(String, Data)] = [
            ("Behavior Pack/manifest.json", Data(project.behaviorJSON.utf8)),
            ("Behavior Pack/entities/generated_entity.json", Data(entity.utf8)),
            ("Resource Pack/manifest.json", Data(project.resourceJSON.utf8)),
            ("Resource Pack/entity/generated_entity.json", Data(entity.utf8))
        ]

        let safeName = project.name.replacingOccurrences(of: "/", with: "_")
        let output = FileManager.default.temporaryDirectory
            .appendingPathComponent("\(safeName).mcaddon")

        try? FileManager.default.removeItem(at: output)
        try ZipStore.write(files: files, to: output)
        return output
    }
}

private enum ZipStore {
    static func write(files: [(String, Data)], to url: URL) throws {
        var archive = Data()
        var central = Data()
        var offset: UInt32 = 0

        for (name, data) in files {
            let nameData = Data(name.utf8)
            let crc = CRC32.checksum(data)
            let size = UInt32(data.count)

            archive.append(u32(0x04034b50)); archive.append(u16(20))
            archive.append(u16(0)); archive.append(u16(0))
            archive.append(u16(0)); archive.append(u16(0))
            archive.append(u32(crc)); archive.append(u32(size)); archive.append(u32(size))
            archive.append(u16(UInt16(nameData.count))); archive.append(u16(0))
            archive.append(nameData); archive.append(data)

            central.append(u32(0x02014b50)); central.append(u16(20)); central.append(u16(20))
            central.append(u16(0)); central.append(u16(0)); central.append(u16(0)); central.append(u16(0))
            central.append(u32(crc)); central.append(u32(size)); central.append(u32(size))
            central.append(u16(UInt16(nameData.count))); central.append(u16(0)); central.append(u16(0))
            central.append(u16(0)); central.append(u16(0)); central.append(u32(0)); central.append(u32(offset))
            central.append(nameData)

            offset += 30 + UInt32(nameData.count) + size
        }

        let centralOffset = UInt32(archive.count)
        archive.append(central)
        archive.append(u32(0x06054b50)); archive.append(u16(0)); archive.append(u16(0))
        archive.append(u16(UInt16(files.count))); archive.append(u16(UInt16(files.count)))
        archive.append(u32(UInt32(central.count))); archive.append(u32(centralOffset)); archive.append(u16(0))

        try archive.write(to: url, options: .atomic)
    }

    private static func u16(_ v: UInt16) -> Data {
        Data([UInt8(v & 255), UInt8((v >> 8) & 255)])
    }

    private static func u32(_ v: UInt32) -> Data {
        Data([UInt8(v & 255), UInt8((v >> 8) & 255), UInt8((v >> 16) & 255), UInt8((v >> 24) & 255)])
    }
}

private enum CRC32 {
    static let table: [UInt32] = (0..<256).map { i in
        var c = UInt32(i)
        for _ in 0..<8 { c = (c & 1) != 0 ? 0xEDB88320 ^ (c >> 1) : c >> 1 }
        return c
    }

    static func checksum(_ data: Data) -> UInt32 {
        var crc: UInt32 = 0xFFFFFFFF
        for byte in data {
            crc = table[Int((crc ^ UInt32(byte)) & 255)] ^ (crc >> 8)
        }
        return crc ^ 0xFFFFFFFF
    }
}
