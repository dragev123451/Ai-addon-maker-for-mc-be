# AddonAI v1

First working iOS version.

### Working now
- Native SwiftUI UI
- Natural-language addon prompt
- Local starter generator
- Local project persistence
- iOS-safe `.mcaddon` ZIP export
- iOS share sheet

### Build the IPA
Open `AddonAI.xcodeproj` in Xcode on a Mac, select your Apple Developer Team under Signing & Capabilities, then Product → Archive → Distribute App.

An installable IPA cannot be produced in this Linux environment because Apple's signing/provisioning tools and certificates are required.

### AI
The generator is intentionally local in v1. For real AI generation, connect `AddonGenerator` to your own HTTPS backend and keep the model-provider API key on the server.
